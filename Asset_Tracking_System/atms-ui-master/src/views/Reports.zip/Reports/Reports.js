import React, { Component } from 'react'
import './reports.css'
import { getUser } from '../../Service/getUser'
import { Link } from 'react-router-dom'
import moment from "moment";
import { Tabs, Tab } from 'react-bootstrap'
import axios from '../../utils/axiosInstance'
import fileSaver from "file-saver"
import Select from "react-select";
import * as Yup from 'yup';
import { getAmrListTwoDate } from "../../Service/getAmrListTwoDate"
import { getTagList } from "../../Service/getTagList"
import { listAssetTagforTrack } from "../../Service/listAssetTagforTrack"
const SignupSchema = Yup.object().shape({
  type_of: Yup.string().required('Required'),
});
export default class Reports extends Component {
    state = {
        allUsers: [],
        selectAdmin: "",
        amrList: [],
        Role:"",
        loader:false,
        allDevices: [
            {
                value: "abc",
                label: "abc"
            }
            ,
            {
                value: "xyz",
                label: "xyz"
            }
            ,
            {
                value: "pqr",
                label: "pqr"
            }
            ,
            {
                value: "ilj",
                label: "ilj"
            }
            ,
            {
                value: "ilj1",
                label: "ilj1"
            }
            ,
            {
                value: "ilj2",
                label: "ilj2"
            }
        ],
        allTableData: [],
        startDate:"",
        endDate:"",
        AmrID:"",
        tagList: [],
        AssetTag:"",
        Tag:"",
        allGatWay: [],
        selectedGetWay: ""

        
    }
    

    changeDevice=(selectedDevice)=>{
      this.setState({AssetTag:selectedDevice.value},()=>{
        console.log('AssetTag',this.state.Tag)
      })
    }
    async componentDidMount() {
      this.receivedData()
      let resultAssetTrackList = await listAssetTagforTrack();
        console.log('trackdropdown',resultAssetTrackList)
        var setRole =await localStorage.getItem('role');
        let tempArray = []
        if (resultAssetTrackList && resultAssetTrackList.data && resultAssetTrackList.data.length != 0) {
            resultAssetTrackList.data.map((obj) => {
                
                let tempObj = {
                    value: obj,
                    label: obj
                }
                tempArray.push(tempObj)
                
            })
        }
        // let temp=[{}]
        this.setState({tagList: tempArray,Role:setRole,loader:false })

  }
//   clickCard = async (tag) => {
//     this.props.history.push({
//         pathname: `/singleTag-tracking/${tag}`,
//         state: { deviceId: tag },
//     });


// }
  async componentDidMount() {
    try{ this.receivedData()
    let resultAssetTagList = await getTagList();
      console.log('trackdropdown',resultAssetTagList)
      var setRole =await localStorage.getItem('role');
      let tempArray = []
      if (resultAssetTagList && resultAssetTagList.data && resultAssetTagList.data.length != 0) {
          resultAssetTagList.data.map((obj) => {
              
              let tempObj = {
                  value: obj,
                  label: obj
              }
              tempArray.push(tempObj)
              
          })
      }
      // let temp=[{}]
      this.setState({TagList: tempArray,Role:setRole,loader:false }, () => {
          console.log('TagList',this.state.TagList)
          
      })
  }catch (error){
          console.log(error)
          this.setState({loader:false})
      }
  }

    async componentDidMount() {
      try{    this.setState({loader:true})
       let result = await getAmrListTwoDate();
       console.log('result',result);
      var setRole =await localStorage.getItem('role');
      let tempArray = []
      if (result && result.data && result.data.length != 0) {
          result.data.map((obj) => {
              let tempObj = {
                  value: obj,
                  label: obj
              }
              tempArray.push(tempObj)
          })
      }
      // let temp=[{}]
      this.setState({amrList: tempArray,Role:setRole,loader:false }, () => {
          console.log('amrList',this.state.amrList)
          
      })
  }catch (error){
          console.log(error)
          this.setState({loader:false})
      }
  }

    downloadUserFile = async () => {
        
        let token = await localStorage.getItem("token");
        let fkUserId =  await localStorage.getItem('fkUserId');
        let role =await localStorage.getItem('role');
        let firstname =  await localStorage.getItem('firstname');
        let lastname =await localStorage.getItem('lastname');
        axios.get(`/iotmeter/user/get-payload_report_for_user_export_download?fkUserId=${fkUserId}&role=${role}`, {
            headers: { "Authorization": `Bearer ${token}` },
            responseType: 'arraybuffer'
        })
            .then((response) => {
                var blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                fileSaver.saveAs(blob, `${firstname +'_'+ lastname}ReportFile.xls`);
            });

    }
    downloadFile = async () => {
        
        let token = await localStorage.getItem("token")
        let fkUserId =  await localStorage.getItem('fkUserId');
        let role =await localStorage.getItem('role');
        // /payload/get-payload_report_for_admin_export_download
        axios.get(`/iotmeter/payload/get-payload_report_for_admin_export_download?fkUserId=${fkUserId}&role=${role}`, {
            headers: { "Authorization": `Bearer ${token}` },
            responseType: 'arraybuffer'
            
        })
            .then((response) => {
                var blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                fileSaver.saveAs(blob, 'ReportFile.xls');
            });

    }
    downloadDateWisePayloadFile = async () => {
        if(this.state.startDate !=='' && this.state.endDate !==''){
            let token = await localStorage.getItem("token")
            let fkUserId =  await localStorage.getItem('fkUserId');
            let role =await localStorage.getItem('role');
           
            axios.get(`/iotmeter/payload/get-payload_report_between_two_date_for_admin_export_download?amrid=${this.state.AmrID}&fromDate=${this.state.startDate}&toDate=${this.state.endDate}&fkUserId=${fkUserId}&role=${role}`, {
                headers: { "Authorization": `Bearer ${token}` },
                responseType: 'arraybuffer'
            })
                .then((response) => {
                    var blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                    fileSaver.saveAs(blob, 'DateWisePayloadReportFile.xls');
                });
        }else{
            alert('Please Select Date');
        }
    }
   

    startDateValue=(e)=>{
        this.setState({startDate:moment(e.target.value).format("yyyy-MM-DD")},()=>{
          console.log('startdate',this.state.startDate)
        })
        
    }
    
    endDateValue=(e)=>{
        this.setState({endDate:moment(e.target.value).format("yyyy-MM-DD")},()=>{
          console.log('enddate',this.state.endDate)
        })
        
    }
   
      changeTag=(selectedTag)=>{
        this.setState({Tag:selectedTag.value},()=>{
          console.log('Tag',this.state.Tag)
        })  
      }

      changeGetWay = (selectedGetWay) => {

        this.setState({ selectedGetWay: selectedGetWay.value, selectedGetWayId: selectedGetWay.id },()=>{
            console.log('pkGetWayid',this.state.selectedGetWay)
            console.log('selectedGetWayId',this.state.selectedGetWayId)
        })
    }

    render() {
      const { loader } = this.state
        return (
<>
{loader?<div class="loader"></div>:
              <div className="tab-wrapper">
      <div className='container-fluid' >
        <div className="row">
          <div className="col-sm-12">


          {(this.state.Role==='admin') ? 
          (
            <Tabs defaultActiveKey="Payload">
              <Tab eventKey="Payload" title="Gateway_Wise Export">
                <div className="tab-item-wrapper">
                <h5> Gateway_Wise Export</h5>
                <div className="Device__form__wrapper">
                    <div>
                    <label>SELECT GATWAY</label>
                <Select options={this.state.amrList} name="selectDevice" className="payload__select" onChange={this.changeDevice} />
              </div>
              <div>
                  <label>SELECT TAG</label>
                  <Select options={this.state.amrList} name="selectDevice" className="payload__select" onChange={this.changeDevice} />
                </div>
                </div>  
               
                  <p>For Gateway_Wise Export Click on Download Button</p>
                  <button  onClick={this.downloadFile}>EXCEL</button>
                  <button  onClick={this.downloadFile}>PDF</button>
                </div>
              </Tab>

              <Tab eventKey="Date" title="Date Wise Tag Export">
                <div className="tab-item-wrapper">
                <h5>Date Wise Tag Export</h5>
                
                <div className="Device__form__wrapper">
                    <div>
                    <label>Start Date</label>
                    <input className="form-control" type="date" name="sDate"  onChange={this.startDateValue} />
                    </div>
                    <div>
                    <label>End Date</label>
                    <input className="form-control" type="date" name="eDate"  onChange={this.endDateValue} />
                    </div>
                    <div>
                    <label>SELECT NAME</label>
                <Select options={this.state.amrList} name="selectDevice" className="payload__select" onChange={this.changeDevice} />
                    </div>
                </div>          
                <p>For Date Wise Tag Export Click on Download Button</p>
                  <button onClick={this.downloadDateWisePayloadFile}>DOWNLOAD</button>
                </div>
              </Tab>
            </Tabs>
          )
            : this.state.Role==='user'?(<Tabs defaultActiveKey="User">
              <Tab eventKey="User" title="Tag_Wise Export">
                <div className="tab-item-wrapper">
                  <h5>Tag_Wise Export</h5>
                  <div className="Device__form__wrapper">
                    <div>
                    <label>SELECT TAG</label>
                    <Select options={this.state.tagList} className="payload__select" onChange={this.changeDevice} />
              </div>
                </div> 
                <p>For Tag_Wise Export Click on Download Button</p> 
                  <button onClick={this.downloadUserFile}>EXCEL</button>
                  <button onClick={this.downloadUserFile}>PDF</button>
                </div>
              </Tab>


              <Tab eventKey="Date" title="Date Wise Tag Export">
                <div className="tab-item-wrapper">
                <h5>Date Wise Tag Export</h5>
                
                <div className="Device__form__wrapper">
                    <div>
                    <label>Start Date</label>
                    <input className="form-control" type="date" name="sDate"  onChange={this.startDateValue} />
                    </div>
                    <div>
                    <label>End Date</label>
                    <input className="form-control" type="date" name="eDate"  onChange={this.endDateValue} />
                    </div>
                    <div><label><strong>SELECT NAME</strong></label>
                <Select options={this.state.amrList} name="selectDevice" className="payload__select" onChange={this.changeDevice} />
                    </div>
                </div>          
                <p>For Date Wise Tag Export Click on Download Button</p>
                  <button onClick={this.downloadDateWisePayloadFile}>DOWNLOAD</button>
                </div>
              </Tab>
            </Tabs>
)
            :(<Tabs defaultActiveKey="User">
              <Tab eventKey="User" title="Tag_Wise Export">
                <div className="tab-item-wrapper">
                  <h5>Tag_Wise Export</h5>
                  
                  <div className="Device__form__wrapper">
                    <div>
                    <label>SELECT TAG</label>
                    <Select options={this.state.tagList} className="payload__select" onChange={this.changeDevice} />
              </div>
                </div> 
                <p>For Tag_Wise Export Click on Download Button</p> 
                  <button onClick={this.downloadUserFile}>EXCEL</button>
                  <button onClick={this.downloadUserFile}>PDF</button>
                </div>
              </Tab>

              <Tab eventKey="Payload" title="Gateway_Wise Export">
                <div className="tab-item-wrapper">
                <h5>Gateway_Wise Export</h5>
                <div className="Device__form__wrapper">
                    <div>
                    <label>SELECT GATWAY</label>
                <Select options={this.state.allGatWay} name="selectDevice" className="payload__select" onChange={this.changeGetWay} />
              </div>
              <div>
                  <label>SELECT TAG</label>
                  <Select options={this.state.amrList} name="selectDevice" className="payload__select" onChange={this.changeDevice} />
                </div>
                </div>  
               
                  <p>For Gateway_Wise Export Click on Download Button</p>
                  <button  onClick={this.downloadFile}>EXCEL</button>
                  <button  onClick={this.downloadFile}>PDF</button>
                </div>
              </Tab>

              <Tab eventKey="Date" title="Date Wise Tag Export">
                <div className="tab-item-wrapper">
                <h5>Date Wise Tag Export</h5>
                
                <div className="Device__form__wrapper">
                    <div>
                    <label>Start Date</label>
                    <input className="form-control" type="date" name="sDate"  onChange={this.startDateValue} />
                    </div>
                    <div>
                    <label>End Date</label>
                    <input className="form-control" type="date" name="eDate"  onChange={this.endDateValue} />
                    </div>
                    <div>
                    <label>SELECT NAME</label>
                <Select options={this.state.amrList} name="selectDevice" className="payload__select" onChange={this.changeDevice} />
              </div>
                </div>          
                <p>For Date Wise Tag Export Click on Download Button</p>
                  <button onClick={this.downloadDateWisePayloadFile}>EXCEL</button>
                  <button onClick={this.downloadDateWisePayloadFile}>PDF</button>
                  
                </div>
              </Tab>
            </Tabs>
)}

          </div>
        </div>
      </div>
    </div>
}
        </> 
        )
    }
}
